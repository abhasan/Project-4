Introduction:
    1. this is the Udacity Neigborhood Map project main folder
    2. we have "finalproject.py" as our main server side file
    3. besides the main file, we should have other files placed in the same folder and subfolders

How to run the code:
  1. After placing all the files (mentioned above) in the same folder
  2. run the "finalproject.py" file on the server side with command "python finalproject.py"
  2. Make sure you have "Java-script enabled" on your browser
  3. type the following web url in your browser "http://localhost:8000/catalog/"
  4. It will render the html main page in the browser

Preferred webbrowser
  Internet Explorer, Firefox, Google Chrome
